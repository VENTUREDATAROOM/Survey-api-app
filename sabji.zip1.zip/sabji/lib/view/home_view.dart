
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sabji/view/crop_details_view.dart';
import 'package:sabji/view/dashboard_view.dart';
import 'package:sabji/view/driver_details_view.dart';
import 'package:sabji/view/farmer_details_view.dart';
import 'package:sabji/view_models/controller/home_controller.dart';

import 'vender_details_view.dart';


class HomeView extends StatelessWidget {

  HomeView({super.key});

  final HomeController landingPageController = Get.put(HomeController(), permanent: false);

  final TextStyle unselectedLabelStyle = TextStyle(
      color: Colors.white.withOpacity(0.5),
      fontWeight: FontWeight.w500,
      fontSize: 12);

  final TextStyle selectedLabelStyle = const TextStyle(
      color: Colors.white, fontWeight: FontWeight.w500, fontSize: 12);


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        bottomNavigationBar:
        buildBottomNavigationMenu(context, landingPageController),
        body: Obx(() =>
            IndexedStack(
              index: landingPageController.tabIndex.value,
              children:  [
                DashboardView(),
                const CropDetailsView(),
                const DriverDetailsView(),
                const FarmerDetailsView(),
                const VendorDetailsView(),
              ],
            )
        )
    );

  }

  buildBottomNavigationMenu(context, landingPageController) {
    return Obx(() => MediaQuery(
        data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
        child: SizedBox(
          height: 60,
          child: BottomNavigationBar(
            showUnselectedLabels: true,
            showSelectedLabels: true,
            onTap: landingPageController.changeTabIndex,
            currentIndex: landingPageController.tabIndex.value,
            backgroundColor: const Color.fromRGBO(36, 54, 101, 1.0),
            unselectedItemColor: Colors.white.withOpacity(0.5),
            selectedItemColor: Colors.white,
            unselectedLabelStyle: unselectedLabelStyle,
            selectedLabelStyle: selectedLabelStyle,
            items: [
              BottomNavigationBarItem(
                icon: Container(
                  margin: const EdgeInsets.only(bottom: 7),
                  child: const Icon(
                    Icons.home,
                    size: 20.0,
                  ),
                ),
                label: 'Dashboard',
                backgroundColor: const Color.fromRGBO(36, 54, 101, 1.0),
              ),
              BottomNavigationBarItem(
                icon: Container(
                  margin: const EdgeInsets.only(bottom: 7),
                  child: const Icon(
                    Icons.ac_unit,
                    size: 20.0,
                  ),
                ),
                label: 'Crop',
                backgroundColor: const Color.fromRGBO(36, 54, 101, 1.0),
              ),
              BottomNavigationBarItem(
                icon: Container(
                  margin: const EdgeInsets.only(bottom: 7),
                  child: const Icon(
                    Icons.fire_truck,
                    size: 20.0,
                  ),
                ),
                label: 'Transport',
                backgroundColor: const Color.fromRGBO(36, 54, 101, 1.0),
              ),
              BottomNavigationBarItem(
                icon: Container(
                  margin: const EdgeInsets.only(bottom: 7),
                  child: const Icon(
                    Icons.person,
                    size: 20.0,
                  ),
                ),
                label: 'Farmer',
                backgroundColor: const Color.fromRGBO(36, 54, 101, 1.0),
              ),
              BottomNavigationBarItem(
                icon: Container(
                  margin: const EdgeInsets.only(bottom: 7),
                  child: const Icon(
                    Icons.shopping_cart,
                    size: 20.0,
                  ),
                ),
                label: 'Vendor',
                backgroundColor: const Color.fromRGBO(36, 54, 101, 1.0),
              ),
            ],
          ),
        )));
  }
}