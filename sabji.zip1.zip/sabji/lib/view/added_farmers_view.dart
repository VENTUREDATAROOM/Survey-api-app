import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:sabji/view_models/controller/added_farmer_controller.dart';

class AddedFarmersView extends StatelessWidget {
  AddedFarmersView({super.key});
  AddedFarmerController addedFarmerController=Get.put(AddedFarmerController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("My Farmers"),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 19),
            child: Icon(Icons.search,size: 30,),
          )
        ],
      ),
      body: Obx(() => addedFarmerController.isLoading.value?Center(child: CircularProgressIndicator()):ListView.builder(
        shrinkWrap: true,
        itemCount: addedFarmerController.farmers.value.length,
        itemBuilder: (context, index) {
          return Card(
            child: Column(
              children: [
                _buildTableRow("Driver ID", "${addedFarmerController.farmers.value[index]['farmerId']}"),
                _buildTableRow("Farmer Name", "${addedFarmerController.farmers.value[index]['farmerName']}"),
                _buildTableRow("Phone Number", "${addedFarmerController.farmers.value[index]['phoneNumber']}"),
                _buildTableRow("Area", "${addedFarmerController.farmers.value[index]['area']}"),
                _buildTableRow("Vegetable Carrying", "${addedFarmerController.farmers.value[index]['vegCurntCarrying']}"),
                _buildTableRow("Vegetable Carrying Qty", "${addedFarmerController.farmers.value[index]['vegetableQuantity']}"),
                _buildTableRow("Distance From Mandi", "${addedFarmerController.farmers.value[index]['distanceFromMandi']}"),
                _buildTableRow("Transport Name", "${addedFarmerController.farmers.value[index]['transportName']}"),
                _buildTableRow("Farmer Visit", "${addedFarmerController.farmers.value[index]['farmerVisitingCount']}"),
                _buildTableRow("Selling Area", "${addedFarmerController.farmers.value[index]['sellingArea']}"),
                _buildTableRow("Name of Mandi", "${addedFarmerController.farmers.value[index]['nameOfMandi']}"),
                _buildTableRow("Vegetable Variety", "${addedFarmerController.farmers.value[index]['varietyOfVegetables']}"),
                _buildTableRow("Commission", "${addedFarmerController.farmers.value[index]['amountOfCommision']}"),
                // _buildTableRow("User Code", "7460837725"),
              ],
            ),
          );
        },
      )),
    );
  }
  Widget _buildTableRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Text(
          label,
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        VerticalDivider(),
        Text(value),
      ],
    );
  }

}

