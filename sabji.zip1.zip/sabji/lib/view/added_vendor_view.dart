import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sabji/view_models/controller/added_vegetable_controller.dart';
import 'package:sabji/view_models/controller/added_vendor_controller.dart';

class AddedVendorView extends StatefulWidget {
  @override
  _AddedVendorViewState createState() => _AddedVendorViewState();
}

class _AddedVendorViewState extends State<AddedVendorView> {
  final AddedVendorController addedVendorController =
  Get.put(AddedVendorController());

  bool isSearchVisible = false;
  final TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: isSearchVisible ? _buildSearchField() : Text("My Vegetables"),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 20),
            child: IconButton(
              icon: Icon(Icons.search, size: 30),
              onPressed: () {
                // setState(() {
                //   isSearchVisible = !isSearchVisible;
                // });
              },
            ),
          )
        ],
      ),
      body: Obx(
            () => addedVendorController.isLoading.value
            ? Center(child: CircularProgressIndicator())
            : ListView.builder(
          shrinkWrap: true,
          itemCount: addedVendorController.vendors.length,
          itemBuilder: (context, index) {
            return Card(
              child: Column(
                children: [
                  _buildTableRow(
                      "Vendor ID",
                      "${addedVendorController.vendors
                          .value[index]['id']}"),
                  _buildTableRow(
                      "Vendor Name",
                      "${addedVendorController.vendors.value[index]['vendorName']}"),
                  _buildTableRow(
                      "Vendor Age",
                      "${addedVendorController.vendors.value[index]['vendorName']}"),

                  _buildTableRow(
                      "Vendor Number",
                      "${addedVendorController.vendors.value[index]['vendorNumber']}"),
                  _buildTableRow(
                      "Vendor Address",
                      "${addedVendorController.vendors.value[index]['vendorAddress']}"),
                  _buildTableRow(
                      "Shop Address",
                      "${addedVendorController.vendors.value[index]['shopAddress']}"),
                  _buildTableRow(
                      "Mandi Priority",
                      "${addedVendorController.vendors.value[index]['mandiPriority']}"),
                  _buildTableRow(
                      "Vendor Type",
                      "${addedVendorController.vendors.value[index]['vendorType']}"),
                  _buildTableRow(
                      "Vegetable Variety",
                      "${addedVendorController.vendors.value[index]['vegetableVariety']}"),
                  _buildTableRow(
                      "Mandi Visit",
                      "${addedVendorController.vendors.value[index]['mandiVisit']}"),

                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildSearchField() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.white),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: searchController,
              decoration: InputDecoration(
                hintText: 'Search by mobile number',
                border: InputBorder.none,
                contentPadding: EdgeInsets.all(10),
              ),
            ),
          ),
          IconButton(
            icon: Icon(Icons.close),
            onPressed: () {
              setState(() {
                isSearchVisible = false;
                searchController.clear();
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _buildTableRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Text(
          label,
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        VerticalDivider(),
        Text(value),
      ],
    );
  }
}
