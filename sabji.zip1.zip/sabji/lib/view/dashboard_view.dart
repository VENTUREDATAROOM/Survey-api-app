import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sabji/view/added_driver_view.dart';
import 'package:sabji/view/added_vegetable_view.dart';
import 'package:sabji/view_models/controller/dashboard_controller.dart';

import 'added_farmers_view.dart';
import 'added_vendor_view.dart';
import 'custom_text.dart';

class DashboardView extends StatelessWidget {
  DashboardView({super.key});
  final dashboardViewModelController = Get.put(DashboardController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        centerTitle: true,
        automaticallyImplyLeading: false,
        title: Text("survey_profile".tr),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child:  InkWell(
              onTap: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Center(child: Text('Select Language')),
                      actions: [
                        TextButton(
                          onPressed: () {
                             Get.updateLocale(Locale("en", "US"));

                            Navigator.of(context).pop(); // Close the popup
                          },
                          child: Text('English'),
                        ),
                        SizedBox(
                          width: 80,
                        ),
                        TextButton(
                          onPressed: () {
                             Get.updateLocale(Locale("hi", "IN"));
                            Navigator.of(context).pop(); // Close the popup
                          },
                          child: Text('Hindi'),
                        ),
                      ],
                    );
                  },
                );
              }, // Removed the extra comma here
              child: Icon(Icons.settings),
            ),
          )
        ],
      ),

      body: Obx(() => SizedBox.expand(
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  InkWell(
                    onTap: (){
                      Get.to(AddedVegetableView());
                    },
                    child: SizedBox(
                      height: 150,
                      width: 200,
                      child: Card(
                        elevation: 20,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                        child: Center(
                          child: Column(
                            children: [
                              const SizedBox(height: 10,),
                              CustomText(
                                  dashboardViewModelController.cropCount.value
                                      .toString(),
                                  28,FontWeight.bold),
                              const SizedBox(height: 10,),
                               CustomText( "vegetable".tr,
                                  28,FontWeight.bold),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  InkWell(
                    onTap: (){
                      Get.to(AddedDriverView());
                    },
                    child: SizedBox(
                      height: 150,
                      width: 200,
                      child: Card(
                        elevation: 20,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                        child: Center(
                          child: Column(
                            children: [
                              const SizedBox(height: 10,),
                              CustomText(
                                  dashboardViewModelController.driverCount.value
                                      .toString(),
                                  28,FontWeight.bold),
                              const SizedBox(height: 10,),
                               CustomText('driver'.tr,
                                  28,FontWeight.bold),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  InkWell(
                    onTap: (){
                      Get.to(AddedFarmersView());
                    },
                    child: SizedBox(
                      height: 150,
                      width: 200,
                      child: Card(
                        elevation: 20,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                        child: Center(
                          child: Column(
                            children: [
                              const SizedBox(height: 10,),
                              CustomText(
                                  dashboardViewModelController.farmerCount.value
                                      .toString(),
                                  28,FontWeight.bold),
                              const SizedBox(height: 10,),
                               CustomText('farmer'.tr,
                                  28,FontWeight.bold),

                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  InkWell(
                    onTap: (){
                        Get.to(AddedVendorView());
                     print(dashboardViewModelController.vendorCount.value);
                    },
                    child: SizedBox(
                      height: 150,
                      width: 200,
                      child: Card(
                        elevation: 20,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                        child: Center(
                          child: Column(
                            children: [
                              const SizedBox(height: 10,),
                              CustomText(
                                  dashboardViewModelController.vendorCount.value
                                      .toString(),
                                  28,FontWeight.bold),
                              const SizedBox(height: 10,),
                              CustomText('vendor'.tr,
                                  28,FontWeight.bold),

                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )),
    );
  }
}
