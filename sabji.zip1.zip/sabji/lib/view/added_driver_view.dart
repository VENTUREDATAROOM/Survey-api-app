// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:http/http.dart' as http;
// import 'package:sabji/view_models/controller/added_farmer_controller.dart';
//
// class AddedDriver extends StatefulWidget {
//   const AddedDriver({Key? key}) : super(key: key);
//   @override
//   _AddedDriverState createState() => _AddedDriverState();
// }
//
// class _AddedDriverState extends State<AddedDriver> {
//   final addedFarmerController = Get.put(AddedFarmerController());
//   @override
//   void initState() {
//     super.initState();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("My Drivers"),
//         centerTitle: true,
//       ),
//       body: addedFarmerController.isLoading.value
//           ? Center(child: CircularProgressIndicator())
//           : ListView.builder(
//         shrinkWrap: true,
//         itemCount: addedFarmerController.farmers.value.length,
//         itemBuilder: (context, index) {
//           return Dismissible(
//             key: ObjectKey(addedFarmerController.farmers.value[index]),
//             child: Card(
//               child: Container(
//                 margin: EdgeInsets.all(16.0),
//                 padding: EdgeInsets.all(16.0),
//                 decoration: BoxDecoration(
//                   border: Border.all(color: Colors.grey),
//                   borderRadius: BorderRadius.circular(8.0),
//                 ),
//                 child: Column(
//                   children: [
//                     _buildTableRow("farmer ID", addedFarmerController.farmers.value[index]["farmerId"]),
//                     _buildTableRow(
//                         "farmer Name", addedFarmerController.farmers.value[index]["farmername"]),
//                     _buildTableRow("Phone Number",addedFarmerController.farmers.value[index]["phoneNumber"]),
//                     _buildTableRow("Area", addedFarmerController.farmers.value[index]["area"]),
//                     _buildTableRow("Vegetable Carrying Qty",addedFarmerController.farmers.value[index]["vegCurntCarrying"]),
//                     _buildTableRow("Vegetable Produce Qty", addedFarmerController.farmers.value[index]["vegetableQuantity"]),
//                     _buildTableRow("Mandi Distance", addedFarmerController.farmers.value[index]["distanceFromMandi"]),
//                     _buildTableRow("Transport Name", addedFarmerController.farmers.value[index]["transportName"]),
//                     _buildTableRow("Farmer Visit", addedFarmerController.farmers.value[index]["farmerVisitingCount"]),
//                     _buildTableRow("Selling Area", addedFarmerController.farmers.value[index]["sellingArea"]),
//                     _buildTableRow("Mandi Name", addedFarmerController.farmers.value[index]["nameOfMandi"]),
//                     _buildTableRow("Vegetable Variety", addedFarmerController.farmers.value[index]["varietyOfVegetables"]),
//                     _buildTableRow("Commission", addedFarmerController.farmers.value[index]["amountOfCommision"]),
//                     _buildTableRow("User Code", addedFarmerController.farmers.value[index]["quest1"]),
//                     _buildTableRow("User Code", addedFarmerController.farmers.value[index]["quest2"]),
//                     _buildTableRow("User Code", addedFarmerController.farmers.value[index]["quest3"]),
//                     _buildTableRow("User Code", addedFarmerController.farmers.value[index]["quest4"]),
//                     _buildTableRow("User Code", addedFarmerController.farmers.value[index]["userCode"]),
//                   ],
//                 ),
//               ),
//             ),
//           );
//         },
//       ),
//     );
//   }
//
//   Widget _buildTableRow(String label, String value) {
//     return Row(
//       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//       children: [
//         Text(
//           label,
//           style: TextStyle(fontWeight: FontWeight.bold),
//         ),
//         VerticalDivider(),
//         Text(value),
//       ],
//
//       // child: ListTile(
//       //   title: Text('${addedFarmerController.farmers.value[index]['farmerName']}'),
//       //   subtitle: Text('${addedFarmerController.farmers.value[index]['phoneNumber']}'),
//       // )
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sabji/data/response/status.dart';

import '../view_models/controller/added_driver_controller.dart';
class AddedDriverView extends StatelessWidget {
  AddedDriverView({super.key});
  AddedDriverController addedDriverController=Get.put(AddedDriverController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("My Driver"),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 20),
            child: Icon(Icons.search,size: 30,),
          )
        ],
      ),
      body: Obx(() => addedDriverController.isLoading.value?Center(child: CircularProgressIndicator()):ListView.builder(
        shrinkWrap: true,
        itemCount: addedDriverController.drivers.value.length,
        itemBuilder: (context, index) {
          return Card(
            child: Column(
              children: [
                _buildTableRow("Driver ID",
                    "${addedDriverController.drivers.value[index]['driverId']}"),
                _buildTableRow("Vehicle Name",
                    "${addedDriverController.drivers.value[index]['dVechileName']}"),
                _buildTableRow("Vehicle Number",
                    "${addedDriverController.drivers.value[index]['dVechileName']}"),
                _buildTableRow("Quantity of Vegetables", "${addedDriverController.drivers.value[index]['quantityOfVegetables']}"),
                _buildTableRow("Round Count",
                    "${addedDriverController.drivers.value[index]['roundCount']}"),
                _buildTableRow("Driver Area",
                    "${addedDriverController.drivers.value[index]['driverArea']}"),
                _buildTableRow("Vehicle Owner Name",
                    "${addedDriverController.drivers.value[index]['vechileOwnerName']}"),
                _buildTableRow("Driver Number",
                    "${addedDriverController.drivers.value[index]['driverNumber']}"),
                _buildTableRow("Driver Alternate Number",
                    "${addedDriverController.drivers.value[index]['driverNumber']}"),
                // _buildTableRow("User Code", "7460837725"),
              ],
            ),
          );
        },
      ),
      ),
    );
  }

  Widget _buildTableRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Text(
          label,
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        VerticalDivider(),
        Text(value),
      ],
    );
  }
}