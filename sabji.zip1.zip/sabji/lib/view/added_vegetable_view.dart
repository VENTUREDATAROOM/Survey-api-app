import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sabji/view_models/controller/added_vegetable_controller.dart';

class AddedVegetableView extends StatefulWidget {
  @override
  _AddedVegetableViewState createState() => _AddedVegetableViewState();
}

class _AddedVegetableViewState extends State<AddedVegetableView> {
  final AddedVegetableController addedVegetableController =
  Get.put(AddedVegetableController());

  bool isSearchVisible = false;
  final TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: isSearchVisible ? _buildSearchField() : Text("My Vegetables"),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 20),
            child: IconButton(
              icon: Icon(Icons.search, size: 30),
              onPressed: () {
                // setState(() {
                //   isSearchVisible = !isSearchVisible;
                // });
              },
            ),
          )
        ],
      ),
      body: Obx(
            () => addedVegetableController.isLoading.value
            ? Center(child: CircularProgressIndicator())
            : ListView.builder(
          shrinkWrap: true,
          itemCount: addedVegetableController.vegetables.length,
          itemBuilder: (context, index) {
            return Card(
              child: Column(
                children: [
                  _buildTableRow(
                      "Vegetable ID",
                      "${addedVegetableController.vegetables.value[index]['vegId']}"),
                  _buildTableRow(
                      "Vegetable Name",
                      "${addedVegetableController.vegetables.value[index]['vegetableName']}"),
                  _buildTableRow(
                      "Time Period",
                      "${addedVegetableController.vegetables.value[index]['timeperiod']}"),
                  _buildTableRow(
                      "Vegetable Validity",
                      "${addedVegetableController.vegetables.value[index]['vegetableValidity']}"),
                  _buildTableRow(
                      "Cold Storage Require",
                      "${addedVegetableController.vegetables.value[index]['coldStorageRequirement']}"),
                  _buildTableRow(
                      "Kaha Se Aati He",
                      "${addedVegetableController.vegetables.value[index]['kahaSetAtiHai']}"),
                  _buildTableRow(
                      "Vegetable Availability",
                      "${addedVegetableController.vegetables.value[index]['availability']}"),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildSearchField() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.white),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: searchController,
              decoration: InputDecoration(
                hintText: 'Search by mobile number',
                border: InputBorder.none,
                contentPadding: EdgeInsets.all(10),
              ),
            ),
          ),
          IconButton(
            icon: Icon(Icons.close),
            onPressed: () {
              setState(() {
                isSearchVisible = false;
                searchController.clear();
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _buildTableRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Text(
          label,
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        VerticalDivider(),
        Text(value),
      ],
    );
  }
}
