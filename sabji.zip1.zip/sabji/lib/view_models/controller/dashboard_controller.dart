import 'package:get/get.dart';

import '../../data/repository/dashboard_repository.dart';
import '../../res/constants/app_constants.dart';
import '../../utils/utils.dart';

class DashboardController extends GetxController {
  var cropCount = 0.obs;
  var farmerCount = 0.obs;
  var driverCount = 0.obs;
  var vendorCount = 0.obs;
  final _api = DashboardDetailsRepository();


  @override
  void onInit() {
    getCropDetailsCount();
    getDriverDetailsCount();
    getFarmerDetailsCount();
  }

  void getCropDetailsCount() {
    _api.getCropRecordsCountApi().then((value) {
      if (value[AppConstants.requestCustomCode] == "200") {
        cropCount.value=value[AppConstants.result];
        cropCount.refresh();
      } else {
      }
    }).onError((error, stackTrace) {
      Utils.snackBar('Error', error.toString());
    });
  }
  void getDriverDetailsCount() {
    _api.getDriverRecordsCountApi().then((value) {
      if (value[AppConstants.requestCustomCode] == "200") {
        driverCount.value=value[AppConstants.result];
        driverCount.refresh();
      } else {
      }
    }).onError((error, stackTrace) {
      Utils.snackBar('Error', error.toString());
    });
  }
  void getFarmerDetailsCount() {
    _api.getFarmerRecordsCountApi().then((value) {
      if (value[AppConstants.requestCustomCode] == "200") {
        farmerCount.value=value[AppConstants.result];
        farmerCount.refresh();
      } else {
      }
    }).onError((error, stackTrace) {
      Utils.snackBar('Error', error.toString());
    });
  }
  void getVendorDetailsCount() {
    _api.getVendorRecordsCountApi().then((value) {
      if (value[AppConstants.requestCustomCode] == "200") {
        vendorCount.value=value[AppConstants.result];
        vendorCount.refresh();
        print(vendorCount);
        print("vendorCount");
      } else {
      }
    }).onError((error, stackTrace) {
      Utils.snackBar('Error', error.toString());
    });
  }


}