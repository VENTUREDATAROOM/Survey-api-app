import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sabji/data/repository/farmer_details_repository.dart';

import '../../data/repository/vendor_details_repository.dart';
import '../../res/constants/app_constants.dart';
import '../../res/routes/routes_name.dart';
import '../../utils/shared_preference.dart';
import '../../utils/utils.dart';

class VendorDetailsController extends GetxController {
  final _api = VendorDetailsRepository();
  List<String> vendorTypeList = <String>['Wholesaler/थोक विक्रेता ', 'Retailer/खुदरा विक्रेता ', 'Small Seller/छोटा विक्रेता', ].obs;
  RxString selectType="".obs;
  List<String> vendorAgeList = <String>['18-25 ', '26-35 ', '36-45',"46-55","56-65","66-75","76-85" ].obs;
  RxString selectAge="".obs;
  List<String> vendorVisitList = <String>['days / दिन', 'Weeks / सप्ताह', 'Months / महीने', ].obs;
  RxString selectVisit="".obs;

  final vendorNameTextController = TextEditingController().obs;
  final vendorTypeTextController = TextEditingController().obs;
  final vendorNumberTextController = TextEditingController().obs;
  final vendorAddressTextController = TextEditingController().obs;
  final shopAddressTextController = TextEditingController().obs;
  final mandiPriorityTextController = TextEditingController().obs;
  final mandiVisitTextController = TextEditingController().obs;
  final vegetableVarietyTextController = TextEditingController().obs;
  final vendorAlternateNumTextController=TextEditingController().obs;

  RxBool loading = false.obs;
  final selectVendorType = "".obs;
  final selectVendorAge = "".obs;


  @override
  void onClose() {

  }
  void setSelectType(String? newValue) {
    selectType.value = newValue!;
    update();
  }

  void addVendorDetailsApi() {
    loading.value = true;
    Map data = {
      "farmerName": vendorNameTextController.value.text.toString(),
      "vendorType":vendorTypeTextController.value.text.toString(),
      "vendorNumber":vendorNameTextController.value.text.toString(),
      "vendorAlternateNumber":vendorAlternateNumTextController.value.text.toString(),
      "vendorAddress":vendorAddressTextController.value.text.toString(),
      "shopAddress":shopAddressTextController.value.text.toString(),
      "mandiPriority":mandiPriorityTextController.value.text.toString(),
      "mandiVisit":mandiVisitTextController.value.text.toString(),
      "vegetableVariety":vegetableVarietyTextController.value.text.toString(),
      "userCode": PreferenceUtils.getString(AppConstants.userId)
    };
    _api.addVendorDetailsApi(data).then((value) {
      print(value);
      print("valuee");
      loading.value = false;
      if (value[AppConstants.requestCustomCode] == "200") {
        resetForm();
        Get.toNamed(RouteName.homeView);
        Utils.snackBar('Vendor Details', 'Vendor details added successfully');
      } else {
        Utils.snackBar(
          'Vendor Details',
          'Unable to add vendor details',
        );
      }

    }).onError((error, stackTrace) {
      loading.value = false;
      Utils.snackBar('Error', error.toString());
    });
  }

  void resetForm(){
    vendorNameTextController.value.text='';
    vendorTypeTextController.value.text='';
    vendorNumberTextController.value.text='';
    vendorAddressTextController.value.text='';
    shopAddressTextController.value.text='';
    mandiPriorityTextController.value.text='';
    mandiVisitTextController.value.text='';
    vegetableVarietyTextController.value.text='';
    vendorAlternateNumTextController.value.text='';
    update();

  }


}
