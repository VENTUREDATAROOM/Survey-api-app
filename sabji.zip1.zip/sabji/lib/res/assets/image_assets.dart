class ImageAssets {
  static const String splashScreenImage = 'assets/images/cartoon.png';
  static const String splashScreenIcon = 'assets/icons/farmer.svg';
  static const String noInternetImage = 'assets/images/no_internet.png';

}