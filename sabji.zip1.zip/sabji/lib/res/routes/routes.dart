import 'package:get/get.dart';
import 'package:sabji/res/routes/routes_name.dart';
import 'package:sabji/view/home_view.dart';
import 'package:sabji/view/language_screen.dart';
import 'package:sabji/view/login_view.dart';
import 'package:sabji/view/registration_view.dart';
import 'package:sabji/view/splash_screen.dart';

import '../components/internet_exception_view.dart';

class AppRoutes
{
  static appRoutes() =>[
    GetPage(
      name:RouteName.splashScreen,
      page:()=>const SplashScreen(),
      transitionDuration: const Duration(milliseconds: 200),
      transition: Transition.leftToRight
    ),
    GetPage(name:RouteName.languageScreen,
        page: ()=>const LanguageScreen(),
        transitionDuration: const Duration(milliseconds: 200),
        transition: Transition.leftToRight),
    GetPage(
        name:RouteName.loginView,
        page:()=>const LoginView(),
        transitionDuration: const Duration(milliseconds: 200),
        transition: Transition.leftToRight
    ),
    GetPage(
        name:RouteName.registrationView,
        page:()=>const RegistrationView(),
        transitionDuration: const Duration(milliseconds: 200),
        transition: Transition.leftToRight
    ),
    GetPage(
        name:RouteName.homeView,
        page:()=>HomeView(),
        transitionDuration: const Duration(milliseconds: 200),
        transition: Transition.leftToRight
    ),
    GetPage(
        name:RouteName.internetExceptionView,
        page:()=> InternetExceptionWidget(onPress: (){},),
        transitionDuration: const Duration(milliseconds: 200),
        transition: Transition.leftToRight
    )
  ];
}