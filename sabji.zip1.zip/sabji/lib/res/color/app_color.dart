import 'dart:ui';

import 'package:flutter/material.dart';

class AppColor{
  static const Color blackColor = Colors.black;
  static const Color blueColor = Colors.blue;
  static const Color backgroundColor =  Colors.white;
  static const Color splashColor =  Colors.white38;

}