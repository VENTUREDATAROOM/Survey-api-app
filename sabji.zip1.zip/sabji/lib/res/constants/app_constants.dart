class AppConstants{

  static const String token="TOKEN";
  static const String requestCustomCode = "customcode";
  static const String result = "result";
  static const String requestToken = "token";
  static const String userId = "USERID";
}