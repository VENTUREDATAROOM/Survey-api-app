import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sabji/utils/utils.dart';

class EditTextUtils {
  TextFormField getCustomEditTextArea(
      {String labelValue = "",
      String hintValue = "",
      required FormFieldValidator<String> validator,
      required TextEditingController controller,
      required TextInputType keyboardType,
      required TextStyle textStyle,
      required bool obscureText,
      required String validationErrorMsg})
  {
    TextFormField textFormField = TextFormField(
      keyboardType: keyboardType,
      style: textStyle,
      controller: controller,
      obscureText: obscureText,
      validator: validator,
      decoration: InputDecoration(
          labelText: labelValue.tr,
          hintText: hintValue.tr,
          labelStyle: textStyle,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(5.0))),
    );
    return textFormField;
  }
}
