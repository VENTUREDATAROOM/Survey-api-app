class FontAssets{
  static const String Schuyler = 'Schuyler';
}