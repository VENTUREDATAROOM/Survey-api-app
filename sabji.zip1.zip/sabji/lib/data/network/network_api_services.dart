import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:sabji/data/app_exceptions.dart';
import 'package:sabji/data/network/base_api_services.dart';
import 'package:http/http.dart' as http;

class NetworkApiServices extends BaseApiServices {


  @override
  Future<dynamic> getApi(String url,String token) async {
    // TODO: implement getApi

    if (kDebugMode) {
      print(url);
    }

    Map<String, String> requestHeaders = {
      "Content-Type": "application/json",
      "Accept": "application/json",
      "Authorization": "Bearer $token",
    };
    try {
      final response = await http.get(Uri.parse(url),
          headers: requestHeaders).timeout(const Duration(seconds: 10));
      return jsonDecode(response.body);
    } on SocketException {
      throw InternetException();
    }

  }

  @override
  Future<dynamic> postApi(var data, String url, String token) async {
    // TODO: implement getApi

    try {
      Map<String, String> requestHeaders = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": "Bearer $token",
      };
      if (kDebugMode) {
        print(url);
        print(jsonEncode(data));
        print(requestHeaders);
      }
      final response = await http
          .post(
            Uri.parse(url),
            headers: requestHeaders,
            body: jsonEncode(data),
          )
          .timeout(const Duration(seconds: 10));
      print(response.body);
      return jsonDecode(response.body);
    } on SocketException {
      throw InternetException();
    } on RequestTimeoutException {
      throw RequestTimeoutException();
    }

  }

  @override
  Future postApiEncoded(data, String url, String token) async {
    // TODO: implement getApi

    if (kDebugMode) {
      print(url);
      print(data);
    }


    try {
      Map<String, String> requestHeaders = {
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json",
        "Authorization": "Bearer $token",
      };
      final response = await http
          .post(
        Uri.parse(url),
        headers: requestHeaders,
        body: data,
      )
          .timeout(const Duration(seconds: 10));
      return jsonDecode(response.body);
    } on SocketException {
      throw InternetException();
    } on RequestTimeoutException {
      throw RequestTimeoutException();
    }
  }
}
