package com.tech.sabji

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
